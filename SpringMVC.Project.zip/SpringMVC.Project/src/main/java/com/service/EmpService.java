package com.service;

import java.util.List;

import com.model.Employee;

public interface EmpService {
	public void add(Employee emp);
	public void update(Employee emp);
	List<Employee> getAll();
	public void delete(Employee emp);
	Employee getById(int id);
}
