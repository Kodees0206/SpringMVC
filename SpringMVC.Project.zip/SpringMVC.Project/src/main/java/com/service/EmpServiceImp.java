package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.EmpDAO;
import com.model.Employee;

@Service
public class EmpServiceImp implements EmpService {
	
	@Autowired
	EmpDAO dao;
	
	@Override
	public void add(Employee emp) {
		dao.add(emp);	
	}

	@Override
	public void update(Employee emp) {
		dao.update(emp);	
	}

	@Override
	public List<Employee> getAll() {	
		return dao.getAll() ;
	}

	@Override
	public void delete(Employee emp) {
		dao.delete(emp);	
	}

	@Override
	public Employee getById(int id) {
		return dao.getById(id) ;
	}

}
