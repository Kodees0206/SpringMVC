package com.dao;

import java.util.ArrayList;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Repository;
import com.model.Employee;

@Repository
public class EmpDAOimp implements EmpDAO {

	@Override
	public void add(Employee emp) {
		SessionFactory fact=new Configuration().configure().buildSessionFactory();
		Session se=fact.openSession();
		Transaction tx=se.beginTransaction();
		se.save(emp);
		tx.commit();
	}

	@Override
	public void update(Employee emp) {
		SessionFactory fact=new Configuration().configure().buildSessionFactory();
		Session se=fact.openSession();
		Transaction tx=se.beginTransaction();
		se.update(emp);
		tx.commit();
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Employee> getAll() {
		List<Employee> empl=new ArrayList<>();
		SessionFactory fact=new Configuration().configure().buildSessionFactory();
		Session se=fact.openSession();
		Transaction tx=se.beginTransaction();
		empl=se.createQuery("from Employee").list();
		tx.commit();
		return empl;
	}

	@Override
	public void delete(Employee emp) {
		SessionFactory fact=new Configuration().configure().buildSessionFactory();
		Session se=fact.openSession();
		Transaction tx=se.beginTransaction();
		se.delete(emp);
		tx.commit();
		
	}

	@Override
	public Employee getById(int id) {
		SessionFactory fact=new Configuration().configure().buildSessionFactory();
		Session se=fact.openSession();
		Transaction tx=se.beginTransaction();
		Employee emp=se.get(Employee.class,id);
		tx.commit();
		return emp;
	}

}
