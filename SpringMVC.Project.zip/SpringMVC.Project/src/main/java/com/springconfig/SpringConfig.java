package com.springconfig;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.thymeleaf.spring5.SpringTemplateEngine;
import org.thymeleaf.spring5.templateresolver.SpringResourceTemplateResolver;
import org.thymeleaf.spring5.view.ThymeleafViewResolver;
import org.thymeleaf.templatemode.TemplateMode;

@Configuration  
@EnableWebMvc
@ComponentScan("com")
public class SpringConfig {

	@Autowired
	private ApplicationContext applicationContext;

	@Bean
	public SpringResourceTemplateResolver templateResolver() {
		//this is the object which finds the front-end files - locate
		SpringResourceTemplateResolver resolver = new SpringResourceTemplateResolver();
		resolver.setPrefix("WEB-INF/view/");
		resolver.setSuffix(".html");
		resolver.setTemplateMode(TemplateMode.HTML);
		resolver.setApplicationContext(applicationContext);
		return resolver;
	}

	@Bean
	public SpringTemplateEngine templateEngine() {
		//load the file found by the resolver
		SpringTemplateEngine engine = new SpringTemplateEngine();
		//mapping the engine to the resolver
		engine.setTemplateResolver(templateResolver());
		//  for accepting the expression language ( ${} )
		engine.setEnableSpringELCompiler(true); // expression language compiler
		return engine;
	}

	@Bean
	public ThymeleafViewResolver viewResolver() {
		// Thyme-leaf object
		ThymeleafViewResolver vr = new ThymeleafViewResolver();
		// loader-engine
		vr.setTemplateEngine(templateEngine());
		return vr;
	}

}
