package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.model.Employee;
import com.service.EmpService;
import org.springframework.stereotype.Controller;

@Controller
public class EmployeeController {
	@Autowired
	EmpService service;
	
	@RequestMapping("/")
	String homepage() {
		return "home";
	}
	@RequestMapping("/employee/showall")
	public String showEmployess(Model data) {
		List<Employee>empl=service.getAll();
		data.addAttribute("employee", empl);
		return "employeePage";  
	}

	@RequestMapping("employee/add")
	public String addEmp() {
		return "addEmployee"; // return to add employee form addEmployee.html
	}

	@PostMapping("employee/insert") // post method mapping for add form
	public String add(@RequestParam String name, @RequestParam String address,
			@RequestParam String phone, @RequestParam float salary, Model data) {
		
		Employee e1 = new Employee(0, name, address, phone, salary);
		service.add(e1);
		data.addAttribute("employee", e1);
		return "employeePage"; 
	}
	@PostMapping("employee/delete")
	public String deleteemp(@RequestParam int id,Model data) {
		
		Employee e1=new Employee(id, null, null, null, 0);
		service.delete(e1);
		List<Employee>empl=service.getAll();
		data.addAttribute("employee", empl);
		return "employeePage";
	}
	@PostMapping("employee/update")
	public String updateEmp(@RequestParam int id, Model data) {
		Employee emp=service.getById(id);
		data.addAttribute("employee", emp);
		return "updatePage";
		
	}
	@PostMapping("employee/updateEmp")
	public String updateemp(@RequestParam int id,@RequestParam String name, @RequestParam String address,
			@RequestParam String phone, @RequestParam float salary, Model data) {
		
		service.update(new Employee(id, name, address, phone, salary));
		List<Employee>empl=service.getAll();
		data.addAttribute("employee", empl);
		return "employeePage"; 
	}
}
